import os
import time
import random

dir_path = os.path.dirname(os.path.realpath(__file__))

os.chdir(dir_path)
print ("Prinitng",os.getcwd())

from Word_set import wordList,drawHangman




def playerChoice():
    """In this function the player is asked to choose 
    between game mode ,
    if player chooses 1 , the word is given by the computer from set of words
    if player chooses 2 , the word is given by second player manually
    any other choice is invalid"""
    
    print ("Please Choose game mode \n Enter 1 to playe against computer \
                \n Enter 2 to play in challange mode")

    time.sleep(1)

    while True:         
        try:
            choice = int(input(">"))
        except:
            print(" invalid literal for int() with base 10:")
            
        if choice ==1:
            print("single player mode:")
            word = random.choices(wordList)[0].upper()
            break
            
        elif choice == 2:
            print("Challange mode \n")
            while True:
                word = str(input("Enter a word to challaange: ")).upper()
                if word.isalpha():
                    print(chr(27) + "[2J")
                    break
                else:
                    print("Symbol and number are not allowed, please try again")
                    continue
            break
        else:
            print("Please enter a valid choice ")   
            continue 
        
    return word




def playGame(word):
    
    """This fucntion contains all the important aspects of the game
    A list which has all the inputs from user to avoid repetation
    Turn count
    Provion to check if the input from the user is valid or not 
    """
    guessed_letters = []
    turncount = 7
    print("\n")
    blank_spaces = ("_"*len(word))
    print(blank_spaces)
    while True: 
        print(drawHangman[turncount])
        guess = str(input("\n \n Please guess the word:")).upper()
        
        if len(guess) ==1 and guess.isalpha():
            if guess in guessed_letters:
                print(blank_spaces)
                print("You have already entered the word")
            elif guess not in word:
                guessed_letters.append(guess)
                print(blank_spaces)
                print("You have entered a wrong word")
                turncount = turncount-1
                if(turncount == 0):
                    print("The correct word was ",word)
                    print("Game over ...")
                    break
                
            else:
                print("Congratulations")
                guessed_letters.append(guess)
                wordlist = list(blank_spaces)
                indices = [alpha for alpha, letter in enumerate(word) if letter == guess ]
                for index in indices:
                    wordlist[index] = guess
                blank_spaces = "".join(wordlist)
                print(blank_spaces,sep ="")
                
                if "_" not in blank_spaces:
                    print("Congratulations! you have correctly guessed ", word)
                    break
                    
        else:
            print("Please type a valid single character input")
            

def main():
    print ("Welcome to Hangman")
    time.sleep(1)
    word = playerChoice()
    playGame(word)
    ask = str(input("Press any key to quit and Y to play again?\n")).upper()
    while ask == "Y":
        word = playerChoice()
        playGame(word)
        ask = str(input("Press any key to quit and Y to play again?\n")).upper()
           
    
    
if __name__ == "__main__":
    main()