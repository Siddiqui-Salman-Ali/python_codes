# -*- coding: utf-8 -*-
"""
Created on Wed Jun  2 03:21:18 2021

@author: EngrS
"""

import os
dir_path = os.path.dirname(os.path.realpath(__file__))
print(dir_path)



Wordlist = []

for files in os.listdir(dir_path+"\Word_source"):
    with open (os.path.join(dir_path+"\Word_source",files), 'r') as source:
        lines = source.read()
        words = lines.split(" ")


# Getting rid of the duplicate values:
    
Words_list = dict.fromkeys(words)


#getting rid of the characters
replace_char = [ "!","/","." ,";", "-" ,":", ",", "?", "]" , ")" , "(" ,"*" ,"'" , "\n","0","1","2","3","4","5","6","7","8","9"]
#remove_char = []

class HangmanSupport:

    def newWordList(self):
        hangmanWords = Words_list
        for members in replace_char:
            hangmanWordsList = [string.replace(members,"") for string in hangmanWords]
            
        #final_words = [elements for elements in symbol_removed if all(ch not in elements for ch in remove_char)]

    
        return hangmanWordsList
    
    def deathAnimation(self):
        """This fucntion has a list of hangman at different phases"""
        
        deathList = [
                    '''
           __________
              |     |
              O     |
            / | \   |
             /\     |
            |  |    |
                    |
        ------------|-
                    ''' ,
                    '''
            Last Chance
           __________
              |     |
              O     |
            / | \   |
             /      |
            |       |
                    |
        ------------|-
                    ''',
                    '''
           __________
              |     |
              O     |
            / | \   |
                    |
                    |
                    |
        ------------|-
                    ''',
                    '''
           __________
              |     |
              O     |
            / |     |
                    |
                    |
                    |
        ------------|-
                    ''',
                    '''_
            _________
              |     |
              O     |
              |     |
                    |
                    |
                    |
        ------------|-
                    ''',
                    '''_
            _________
              |     |
              O     |
                    |
                    |
                    |
                    |
         -----------|-
                    ''',
                   '''\n
           __________
              |     |
                    |
                    |
                    |
                    |
                    |
        ------------|-
                    ''',

                    
            '''\n
            __________
                    |
                    |
                    |
                    |
                    |
                    |
        ------------|-
                    '''
                    
                    
             ]
        
        return deathList
    
    
wordList = HangmanSupport().newWordList()

drawHangman = HangmanSupport().deathAnimation()

